# coding=utf-8
from countryinfo.countryinfo import CountryInfo
